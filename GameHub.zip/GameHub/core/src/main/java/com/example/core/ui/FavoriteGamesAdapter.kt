package com.example.core.ui

class FavoriteGamesAdapter {
}